 // This is a digital portrait of conversations with my
 // long distance boyfriend who loves dinosaurs.
 // He always brings up the topic in conversation so I
 // decided to see how many times we've mentioned the
 // word "dinosaur" in our chat.

 // PRESS SPACE BAR TO CHANGE CONVERSATION
 // PRESS D KEY TO HIGHLIGHT THE WORD "DINOSAURS" to see how many times we've said "dinosaur" in chat

//I used arrays for the conversations, 
//lerp, scale, and pow to animate speech bubbles 
//scenes, keypress, for spacebar and D key/ interactions

let scene = 0;
let highlightD = false;

let blueDino;
let pinkDino;

let animationStart = 0;
let bubbleDelay = 450;
let bubbleDuration = 550;

let bubbleWidth = 290;
let bubbleGap = 15;
let lineHeight = 22;
let spaceWidth = 7;

let conversations = [

  // Convo 1
  [
    { text: "2 years ago", sender: "left" },
    { text: "We saw the dinosaurs in Tokyo", sender: "left" },
    { text: "Ay nako", sender: "left" },
    { text: "Lets go back", sender: "left" },
    { text: "Ok darling next time again", sender: "right" }
  ],

  // Convo 2
  [
    { text: "Lets go to the romantic part of the US", sender: "left" },
    { text: "AHAHAHAHAHA", sender: "left" },
    { text: "like uhhh", sender: "left" },
    { text: "North Dakota", sender: "left" },
    { text: "And look at dinosaurs", sender: "left" }
  ],

  // Convo 3
  [
    { text: "I'll try to visit you soon and we can spend time together", sender: "left" },
    { text: "and look at the dinosaurs", sender: "left" },
    { text: "its okey no pressure its expensive", sender: "right" },
    { text: "no I want to see the dinosaurs", sender: "left" },
    { text: "and u", sender: "left" },
    { text: "so ur only going for the dinosaurs hmph", sender: "right" }
  ],

  // Convo 4
  [
    { text: "and u", sender: "left" },
    { text: "no so I'm the side reason and not the main reason", sender: "right" },
    { text: "well they're dinosaurs", sender: "left" }
  ],

  // Convo 5
  [
    { text: "its like how ur going to sg cuz of bts and not to spend time w me", sender: "left" },
    { text: "I'm the side reason also", sender: "left" },
    { text: "and I can say that cuz I paid for the ticket HAHAHAHAHAHA", sender: "left" },
    { text: "ok fine", sender: "right" },
    { text: "exactly", sender: "left" },
    { text: "but this is dinosaurs", sender: "left" }
  ],

  // Convo 6
  [
    { text: "I'm joking ofc I want to see u", sender: "left" },
    { text: "excuse me", sender: "left" },
    { text: "weh", sender: "right" },
    { text: "yea", sender: "left" },
    { text: "dinosaurs don't have boobs", sender: "left" }
  ],

  // Convo 7
  [
    { text: "the theme I was originally going for was", sender: "left" },
    { text: "the best dinosaur museums in europe", sender: "left" },
    { text: "get those friends u only see once in ur life but u had the best night ever", sender: "right" },
    { text: "oh yea ofc", sender: "left" }
  ],

  // Convo 8
  [
    { text: "I love you", sender: "left" },
    { text: "more than dinosaurs", sender: "left" },
    { text: "and Arsenal", sender: "left" },
    { text: "and maybe good food", sender: "left" }
  ],

  // Convo 9
  [
    { text: "I like dinosaurs", sender: "left" },
    { text: "I know", sender: "right" }
  ],

  // Convo 10
  [
    { text: "WOH", sender: "left" },
    { text: "HEY", sender: "left" },
    { text: "I WANT", sender: "left" },
    { text: "TO GO TO", sender: "left" },
    { text: "UNIVERSAL", sender: "left" },
    { text: "I WANT", sender: "left" },
    { text: "DINOSAURS", sender: "left" }
  ],

  // Convo 11
  [
    { text: "we didnt do jurassic", sender: "right" },
    { text: "we didnt wanna get wet", sender: "right" },
    { text: "so boring", sender: "left" },
    { text: "how did u not do dinosaurs", sender: "left" },
    { text: "did u not see my pictures", sender: "right" },
    { text: "i got u dinosaurs pics kaya", sender: "right" }
  ],

  // Convo 12
  [
    { text: "Matthew look the dinosaur moves", sender: "right" },
    { text: "THE DINOSAUR MOVESSSSS", sender: "left" },
    { text: "ok lets go there", sender: "left" }
  ],

  // Convo 13
  [
    { text: "ay nako the brontosaurus isn't a real dinosaur", sender: "left" },
    { text: "whoops", sender: "right" }
  ],

  // Convo 14
  [
    { text: "lets go to the like that in Colorado", sender: "left" },
    { text: "Most dinosaur fossils were found there", sender: "left" },
    { text: "and Canada so theres lots of museums", sender: "left" },
    { text: "so lets go there", sender: "left" },
    { text: "hehehe", sender: "left" }
  ],

  // Convo 15
  [
    { text: "I had like 3 dollhouses HAHHAHA", sender: "right" },
    { text: "mine was dinosaurs :>>", sender: "left" }
  ],

  // Convo 16
  [
    { text: "I had that dinosaur shirt for like", sender: "left" },
    { text: "5 years", sender: "left" }
  ],

  // Convo 17
  [
    { text: "u know how theres like", sender: "left" },
    { text: "a big dinosaur fossil skeleton there", sender: "left" },
    { text: "yea I attached the tail", sender: "left" }
  ],

  // Convo 18
  [
    { text: "My tito was in charge of that", sender: "left" },
    { text: "So I", sender: "left" },
    { text: "Put the tail", sender: "left" },
    { text: "Of the dinosaur", sender: "left" }
  ],

  // Convo 19
  [
    { text: "I have toy cars", sender: "left" },
    { text: "and dinosaurs", sender: "left" }
  ],

  // Convo 20
  [
    { text: "Well meteors can't be controlled", sender: "left" },
    { text: "and dinosaurs liked 200 million years", sender: "left" },
    { text: "We've lived like 5000", sender: "left" }
  ],

  // Convo 21
  [
    { text: "We've had the earth 200 million years", sender: "left" },
    { text: "if it survives literally meteors which made dinosurs extinct", sender: "left" },
    { text: "we can survive this", sender: "left" },
    { text: "yea but then all the dinosaurs fucking died ", sender: "right" }
  ],

  // Convo 22
  [
    { text: "the socks I have so far are", sender: "left" },
    { text: "bananas, star wars, comics, chips, spiderman", sender: "left" },
    { text: "dinosaurs , pandas, penguins, NYC", sender: "left" },
    { text: "BUT HEY I NEED MORE SO", sender: "left" }
  ]
];

async function setup() {
  createCanvas(800, 700);

  textFont("Arial");
  textSize(18);
  textAlign(LEFT);

  blueDino = await loadImage("Dino_-removebg-preview.png");
  pinkDino = await loadImage("_ (20).jpeg");

  animationStart = millis();
}

// CALCULATE HOW MANY LINES EACH MESSAGE NEEDS
function getBubbleHeight(message) {
  let words = message.split(" ");

  let currentWidth = 0;
  let lines = 1;
  let maxWidth = bubbleWidth - 30;

  textFont("Arial");
  textSize(18);

  for (let i = 0; i < words.length; i++) {
    let wordWidth = textWidth(words[i]);

    if (
      currentWidth > 0 &&
      currentWidth + wordWidth > maxWidth
    ) {
      lines++;
      currentWidth = 0;
    }

    currentWidth += wordWidth + spaceWidth;
  }

 
  return max(60, 25 + lines * lineHeight + 15);
}


function draw() {
  background(255);

  let messages = conversations[scene];

  textFont("Arial");
  textSize(18);
  textAlign(LEFT);

  // #41
  if (highlightD) {
    fill(0);
    noStroke();
    textSize(30);
    textAlign(RIGHT);
    text("41", width - 30, 45);
  }

  textSize(18);
  textAlign(LEFT);

  // DINOSAUR PICS
  if (blueDino) {
    image(blueDino, 15, 510, 150, 150);
  }

  if (pinkDino) {
    image(pinkDino, 635, 510, 150, 150);
  }

  let nextY = 65;
  for (let i = 0; i < messages.length; i++) {
    let message = messages[i];
    let bubbleHeight = getBubbleHeight(message.text);
    let targetY = nextY;
    nextY += bubbleHeight + bubbleGap;

    // ANIMATION
    let elapsed = millis() - animationStart - i * bubbleDelay;

    if (elapsed < 0) {
      continue;
    }

    let progress = constrain(
      elapsed / bubbleDuration,
      0,
      1
    );

    progress = 1 - pow(1 - progress, 3);

    let targetX;
    let startX;
    if (message.sender === "left") {
      targetX = 170;
      startX = 125;
    } else {
      targetX = 340;
      startX = 660;
    }

    // COME FROM DINOSAUR MOUTH
    let x = lerp(startX, targetX, progress);
    let y = lerp(545, targetY, progress);

    // GROW SPEECH BUBBLE
    let scaleAmount = lerp(0.15, 1, progress);

    push();
    translate(x, y);
    scale(scaleAmount);
    noStroke();
    if (message.sender === "left") {
      fill(230);
    } else {
      fill(50, 130, 255);
    }

    rect(0, 0, bubbleWidth, bubbleHeight, 20);
    drawMessage(
      message.text,
      message.sender,
      15,
      25,
      bubbleWidth - 30
    );
    pop();
  }
}

// HIGHLIGHTS
function drawMessage(message, sender, x, y, maxWidth) {
  let words = message.split(" ");

  let currentX = x;
  let currentY = y;
  textFont("Arial");
  textSize(18);
  textAlign(LEFT);
  
  for (let i = 0; i < words.length; i++) {
    let word = words[i];
    let wordWidth = textWidth(word);

    if (
      currentX > x &&
      currentX + wordWidth > x + maxWidth
    ) {
      currentX = x;
      currentY += lineHeight;
    }

  
    if (
      highlightD &&
      word.toLowerCase().includes("dinosaur")
    ) {
      fill(255, 255, 0);
      noStroke();
      rect(
        currentX - 2,
        currentY - 17,
        wordWidth + 4,
        22,
        3
      );
    }
    if (sender === "left") {
      fill(0);
    } else {
      fill(255);
    }

    text(word, currentX, currentY);
    currentX += wordWidth + spaceWidth;
  }
}

function keyPressed() {

  // NEXT CONVO 
  if (key === " ") {
    scene++;

    if (scene >= conversations.length) {
      scene = 0;
    }

    animationStart = millis();
    return false;
  }
  
  if (key === "d" || key === "D") {
    highlightD = !highlightD;
  }
}
